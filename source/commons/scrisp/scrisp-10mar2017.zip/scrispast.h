//
//  scrispast.h
//  bach
//
//  Created by Andrea Agostini on 07/03/17.
//
//

#ifndef _SCRISPAST_H_
#define _SCRISPAST_H_

#include "llllobj.h"

typedef enum {
    eNone = 0,
    eK,
    eInlet,
    
    eUMinus,
    ePlus,
    eMinus,
    eTimes,
    eDiv,
    
    eEqual,

    eLogAnd,
    eLogOr,
    
    eIfThenElse,

    eSeq,
    
    eConcat,
    eWrap
} eScrispNodeType;

typedef struct _astDataK {
    t_llll *ll;
} t_astDataK;

typedef struct _astDataInlet {
    long num;
} t_astDataInlet;

typedef struct _astData3 {
    struct _astNode *node1;
    struct _astNode *node2;
    struct _astNode *node3;
} t_astData3;

typedef union _astNodeData {
    t_astDataK      k;
    t_astDataInlet  inlet;
    t_astData3      data3;
} t_astNodeData;

typedef struct _astNode {
    eScrispNodeType type;
    t_astNodeData   data;
} t_astNode;

t_astNode *bisonparse(char *buf, long *maxvars);

t_astNode *astNodeK_new(t_llll *ll);
t_astNode *astNodeInlet_new(long num);
t_astNode *astNode3_new(eScrispNodeType type, t_astNode *n1, t_astNode *n2, t_astNode *n3);
t_llll *ast_eval(t_astNode *node, t_llllobj_object *obj);
void ast_free(t_astNode *node);

#endif /* _SCRISPAST_H_ */